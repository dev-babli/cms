(()=>{var e={};e.id=264,e.ids=[264],e.modules={10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64939:e=>{"use strict";e.exports=import("pg")},93130:(e,t,s)=>{"use strict";s.a(e,async(e,i)=>{try{s.r(t),s.d(t,{patchFetch:()=>p,routeModule:()=>n,serverHooks:()=>h,workAsyncStorage:()=>c,workUnitAsyncStorage:()=>o});var r=s(42706),d=s(28203),l=s(45994),a=s(67518),u=e([a]);a=(u.then?(await u)():u)[0];let n=new r.AppRouteRouteModule({definition:{kind:d.RouteKind.APP_ROUTE,page:"/api/cron/publish-scheduled/route",pathname:"/api/cron/publish-scheduled",filename:"route",bundlePath:"app/api/cron/publish-scheduled/route"},resolvedPagePath:"D:\\Final_Intellectt_cms\\cms_phase1\\cms\\app\\api\\cron\\publish-scheduled\\route.ts",nextConfigOutput:"",userland:a}),{workAsyncStorage:c,workUnitAsyncStorage:o,serverHooks:h}=n;function p(){return(0,l.patchFetch)({workAsyncStorage:c,workUnitAsyncStorage:o})}i()}catch(e){i(e)}})},96487:()=>{},78335:()=>{},67518:(e,t,s)=>{"use strict";s.a(e,async(e,i)=>{try{s.r(t),s.d(t,{GET:()=>a,POST:()=>u});var r=s(39187),d=s(48347),l=e([d]);async function a(e){try{let t=e.headers.get("x-cron-secret")||e.nextUrl.searchParams.get("secret"),s=process.env.CRON_SECRET;if(s&&t!==s)return r.NextResponse.json({success:!1,error:"Unauthorized"},{status:401});console.log("\uD83D\uDD50 Running scheduled publishing job...");let i=await (0,d.K)(),l=i.filter(e=>e.published).length,a=i.filter(e=>!e.published).length;return console.log(`✅ Published ${l} items, ${a} failed`),r.NextResponse.json({success:!0,message:`Published ${l} scheduled items`,results:i,summary:{total:i.length,published:l,failed:a}})}catch(e){return console.error("❌ Scheduled publishing error:",e),r.NextResponse.json({success:!1,error:e?.message||"Failed to publish scheduled content"},{status:500})}}async function u(e){return a(e)}d=(l.then?(await l)():l)[0],i()}catch(e){i(e)}})},48347:(e,t,s)=>{"use strict";s.a(e,async(e,i)=>{try{s.d(t,{K:()=>a});var r=s(62545),d=s(93053),l=e([r,d]);async function a(){let e=[],t=new Date().toISOString();try{for(let s of(await r.Ay.prepare(`
      SELECT id, title, scheduled_publish_date 
      FROM blog_posts 
      WHERE scheduled_publish_date IS NOT NULL 
        AND scheduled_publish_date <= ? 
        AND published = false
    `).all(t)))try{await d.A5.update(s.id,{published:!0,publish_date:s.scheduled_publish_date}),e.push({content_type:"blog",content_id:s.id,title:s.title,published:!0})}catch(t){e.push({content_type:"blog",content_id:s.id,title:s.title,published:!1,error:t.message})}for(let s of(await r.Ay.prepare(`
      SELECT id, title, scheduled_publish_date 
      FROM ebooks 
      WHERE scheduled_publish_date IS NOT NULL 
        AND scheduled_publish_date <= ? 
        AND published = false
    `).all(t)))try{await d.m$.update(s.id,{published:!0,publish_date:s.scheduled_publish_date}),e.push({content_type:"ebook",content_id:s.id,title:s.title,published:!0})}catch(t){e.push({content_type:"ebook",content_id:s.id,title:s.title,published:!1,error:t.message})}for(let s of(await r.Ay.prepare(`
      SELECT id, title, scheduled_publish_date 
      FROM case_studies 
      WHERE scheduled_publish_date IS NOT NULL 
        AND scheduled_publish_date <= ? 
        AND published = false
    `).all(t)))try{await d.II.update(s.id,{published:!0,publish_date:s.scheduled_publish_date}),e.push({content_type:"case_study",content_id:s.id,title:s.title,published:!0})}catch(t){e.push({content_type:"case_study",content_id:s.id,title:s.title,published:!1,error:t.message})}for(let s of(await r.Ay.prepare(`
      SELECT id, title, scheduled_publish_date 
      FROM whitepapers 
      WHERE scheduled_publish_date IS NOT NULL 
        AND scheduled_publish_date <= ? 
        AND published = false
    `).all(t)))try{await d.t4.update(s.id,{published:!0,publish_date:s.scheduled_publish_date}),e.push({content_type:"whitepaper",content_id:s.id,title:s.title,published:!0})}catch(t){e.push({content_type:"whitepaper",content_id:s.id,title:s.title,published:!1,error:t.message})}return e}catch(e){throw console.error("Error in scheduled publishing:",e),e}}[r,d]=l.then?(await l)():l,i()}catch(e){i(e)}})}};var t=require("../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),i=t.X(0,[5994,5452,3053],()=>s(93130));module.exports=i})();